# GIF Studio

A local, self-hosted GIF/animation toolkit inspired by ezgif.com. Runs entirely
on your own machine — nothing is uploaded anywhere. It's a thin, honest web UI
over three real, battle-tested tools:

- **ffmpeg** — video↔GIF, resize, crop, rotate/flip, speed, reverse, text
  overlay, color effects, WebP/APNG/MP4/WebM export
- **gifsicle** — GIF-specific optimization (this is what actually shrinks
  GIF file size well — ffmpeg alone is mediocre at it)
- **ImageMagick** — combining still images into an animated GIF

## What's included (tested and working)

GIF Maker (video→GIF, images→GIF) · Convert (→MP4/WebM/WebP/APNG) · Resize ·
Crop · Rotate/Flip · Speed change · Reverse · Effects (grayscale, sepia,
invert, blur, sharpen, pixelate) · Add text overlay · Optimize (lossy
compression via gifsicle) · Split into frames (zip of PNGs) · Analyzer
(dimensions/duration/frame count/size)

## What's *not* included (ezgif has these, this doesn't — yet)

AVIF and JXL support (needs `libavif`/`libjxl`, less commonly pre-installed —
straightforward to add the same way as the others, see `backend/tools.py`),
animated SVG import (SVG with SMIL/CSS animation really needs a headless
browser to render correctly, which is a much bigger dependency), a crop/resize
**visual** selector (currently you type in pixel coordinates rather than
drag a box on the image — addable with a canvas overlay in `app.js`), batch
processing multiple files in one go, and a job queue for large files (right
now a request blocks until ffmpeg finishes, fine for typical GIF-sized clips
but not for say a 500MB source video).

## Run it — Option A: Docker (recommended, identical on Windows/Linux/macOS)

Requires [Docker Desktop](https://www.docker.com/products/docker-desktop/) (Windows/macOS) or Docker Engine (Linux).

```
docker compose up --build
```

Then open **http://localhost:8000**. That's it — ffmpeg/gifsicle/ImageMagick
are all installed inside the container, so there's nothing else to configure.

## Run it — Option B: natively (no Docker)

You need Python 3.10+ and the three CLI tools on your PATH.

**macOS:**
```
brew install ffmpeg gifsicle imagemagick
./run.sh
```

**Linux (Debian/Ubuntu):**
```
sudo apt-get install ffmpeg gifsicle imagemagick
./run.sh
```

**Windows** (using [Chocolatey](https://chocolatey.org/install), run as admin):
```
choco install ffmpeg gifsicle imagemagick
run.bat
```

Then open **http://localhost:8000**.

## Project layout

```
gifstudio/
  backend/
    main.py         FastAPI routes — one per operation
    tools.py         all the actual ffmpeg/gifsicle/ImageMagick calls
    requirements.txt
  frontend/
    index.html       tab layout, one panel per tool
    app.js            fetch() calls to the backend, result preview/download
    style.css
  Dockerfile
  docker-compose.yml
  run.sh / run.bat
```

## Adding a new operation

1. Write a function in `backend/tools.py` that shells out to the right CLI
   tool (`_run([...])`).
2. Add a route in `backend/main.py` that saves the upload, calls it, returns
   the file.
3. Add a panel + button in `frontend/index.html` and a matching function in
   `Actions` in `frontend/app.js`.

That's the whole extension pattern the rest of the app follows.

## Notes on quality

`video_to_gif` uses ffmpeg's two-pass palette trick (`palettegen` +
`paletteuse`) rather than a naive single-pass conversion — this is the
difference between muddy/banded GIF colors and something close to what
ezgif itself produces. `optimize_gif` deliberately uses gifsicle rather than
ffmpeg, since gifsicle's lossy compression is the actual state of the art for
shrinking existing GIFs.
